import streamlit as st
import controller
import geocoder

# Configuración básica de la página
st.set_page_config(
    page_title="🌦️ ClimaPlus",
    layout="centered",
    initial_sidebar_state="expanded"
)

# Sidebar para búsquedas
with st.sidebar:
    st.title("🔍 Opciones de Búsqueda")
    city = st.text_input("Ingresa una ciudad", key="city_input", placeholder="Ej: Madrid, Tokio")
    
    if st.button("Buscar Clima", type="primary"):
        if not city.strip():
            st.error("Por favor ingresa una ciudad válida")
        else:
            st.session_state.city = city
            st.session_state.lat = None
    
    if st.button("Usar mi ubicación 📍"):
        try:
            g = geocoder.ip('me')
            if g.latlng:
                st.session_state.lat, st.session_state.lon = g.latlng
                st.session_state.city = None
                st.success("Ubicación detectada correctamente")
            else:
                st.error("No se pudo detectar tu ubicación")
        except Exception as e:
            st.error(f"Error de geolocalización: {str(e)}")

# Contenido principal
st.title("🌤️ ClimaPlus - Pronóstico del Tiempo")

# Pantalla de bienvenida (usando solo Markdown nativo de Streamlit)
if not hasattr(st.session_state, 'city') and not hasattr(st.session_state, 'lat'):
    st.markdown("""
    ## ¡Bienvenido a ClimaPlus!
    
    **Consulta el clima actual y el pronóstico extendido de cualquier ciudad del mundo.**
    
    ### 🌦️ Funcionalidades principales:
    - Clima actual con temperatura, humedad y viento
    - Pronóstico de temperaturas en gráfico interactivo
    - Predicciones horarias detalladas
    - Ubicación en mapa interactivo
    
    ### 📌 Instrucciones:
    1. Ingresa una ciudad en el panel izquierdo
    2. Haz clic en **Buscar Clima**
    3. O usa el botón **Usar mi ubicación**
    """)
    
    # Espacio adicional
    st.write("")
    st.image("https://i.imgur.com/pVGh82d.jpeg", width=300, caption="Ilustración del clima")
else:
    # Mostrar contenido climático
    controller.run(
        city=st.session_state.city if hasattr(st.session_state, 'city') else None,
        lat=st.session_state.lat if hasattr(st.session_state, 'lat') else None,
        lon=st.session_state.lon if hasattr(st.session_state, 'lon') else None
    )