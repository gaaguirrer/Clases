import requests
import config
from datetime import datetime

def get_current_weather(city=None, lat=None, lon=None):
    params = {
        "q": city if city else None,
        "lat": lat,
        "lon": lon,
        "appid": config.API_KEY,
        "units": config.UNITS,
        "lang": config.LANG
    }
    response = requests.get(config.CURRENT_WEATHER_URL, params={k: v for k, v in params.items() if v is not None})
    return response.json()

def get_forecast(city=None, lat=None, lon=None):
    params = {
        "q": city if city else None,
        "lat": lat,
        "lon": lon,
        "appid": config.API_KEY,
        "units": config.UNITS,
        "lang": config.LANG
    }
    response = requests.get(config.FORECAST_URL, params={k: v for k, v in params.items() if v is not None})
    return response.json()

def get_air_quality(lat, lon):
    response = requests.get(config.AIR_QUALITY_URL, params={"lat": lat, "lon": lon, "appid": config.API_KEY})
    return response.json()

def get_uv_index(lat, lon):
    response = requests.get(config.UV_API_URL, params={"lat": lat, "lon": lon, "appid": config.API_KEY})
    return response.json()