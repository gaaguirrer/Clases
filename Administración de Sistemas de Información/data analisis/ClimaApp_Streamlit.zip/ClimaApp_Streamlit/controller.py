import model
import view

def run(city=None, lat=None, lon=None):
    current = model.get_current_weather(city, lat, lon)
    forecast = model.get_forecast(city, lat, lon)
    
    view.display_current_weather(current)
    view.display_forecast(forecast)
    
    if lat and lon:
        air_quality = model.get_air_quality(lat, lon)
        view.display_air_quality(air_quality)
    
    # Mostrar recomendaciones agrícolas
    view.display_agricultural_insights(current, city)

