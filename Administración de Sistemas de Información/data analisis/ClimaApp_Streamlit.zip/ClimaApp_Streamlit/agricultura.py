
from datetime import datetime

# 1. Recomendaciones según clima
def recomendaciones_agricolas(temp, humedad, lluvia_prob, ciudad):
    recomendaciones = []

    # Zonas cafetaleras
    if ciudad in ["Estelí", "Matagalpa", "Jinotega"]:
        recomendaciones.append("Zona cafetalera: revise sombra y humedad del cafetal.")

    # Temperaturas altas
    if temp > 32:
        recomendaciones.append("Evite sembrar entre 11 am y 2 pm por calor excesivo.")

    # Riesgo de hongos
    if humedad > 80 and lluvia_prob > 60:
        recomendaciones.append("Alto riesgo de hongos. Use cobertura vegetal o fungicidas naturales.")

    # Condiciones secas
    if lluvia_prob < 20:
        recomendaciones.append("Clima seco. Ideal para preparar suelo o aplicar fertilizantes.")

    return recomendaciones


# 2. Calendario agrícola
CALENDARIO = {
    "Pacífico": {
        "mayo": "Inicio de siembra de maíz.",
        "junio": "Siembra de frijol.",
        "noviembre": "Cosecha de maíz."
    },
    "Norte": {
        "mayo": "Preparar suelo para café.",
        "septiembre": "Floración del café.",
        "diciembre": "Cosecha principal de café."
    },
    "Atlántico": {
        "junio": "Siembra de yuca y plátano.",
        "octubre": "Mantenimiento de cultivos y control de malezas."
    }
}

def ciudad_a_region(ciudad):
    pacifico = ["Managua", "León", "Granada", "Masaya", "Chinandega", "Rivas"]
    norte = ["Estelí", "Matagalpa", "Jinotega", "Somoto", "Ocotal", "Boaco"]
    atlantico = ["Bluefields", "Puerto Cabezas", "Nueva Guinea", "San Carlos"]
    
    if ciudad in pacifico:
        return "Pacífico"
    elif ciudad in norte:
        return "Norte"
    elif ciudad in atlantico:
        return "Atlántico"
    return "Pacífico"  # Por defecto

def calendario_region(ciudad):
    region = ciudad_a_region(ciudad)
    mes_actual = datetime.now().strftime("%B").lower()
    evento = CALENDARIO.get(region, {}).get(mes_actual, "Sin eventos agrícolas registrados para este mes.")
    return region, evento