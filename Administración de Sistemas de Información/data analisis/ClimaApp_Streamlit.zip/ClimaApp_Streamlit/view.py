import config
import streamlit as st
import pandas as pd
import plotly.express as px
from agricultura import recomendaciones_agricolas, calendario_region
from datetime import datetime

WEATHER_ICONS = {
    "clear": "☀️", "clouds": "☁️", "rain": "🌧️",
    "thunderstorm": "⛈️", "snow": "❄️", "mist": "🌫️",
    "drizzle": "🌦️", "fog": "🌁"
}

def display_current_weather(data):
    if data.get("cod") != 200:
        st.error("Error al cargar datos del clima.")
        return

    weather_main = data['weather'][0]['main'].lower()
    icon = WEATHER_ICONS.get(weather_main, "🌤️")

    st.markdown(f"""
    <div style="background: rgba(255,255,255,0.1); border-radius: 10px; padding: 15px; margin: 10px 0">
        <h3 style="margin: 0">{icon} Clima en {data['name']}</h3>
    </div>
    """, unsafe_allow_html=True)

    col1, col2, col3 = st.columns(3)
    col1.metric("🌡️ Temperatura", f"{data['main']['temp']}°C")
    col2.metric("💧 Humedad", f"{data['main']['humidity']}%")
    col3.metric("🌬️ Viento", f"{data['wind']['speed']} m/s")

    st.markdown(f"""
    <div style="background: rgba(255,255,255,0.1); border-radius: 10px; padding: 15px; margin: 10px 0">
        <p><b>Condición:</b> {data['weather'][0]['description'].capitalize()}</p>
        <p><b>Nubosidad:</b> {data['clouds'].get('all', 0)}%</p>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("### 📍 Ubicación")
    map_data = pd.DataFrame({
        "lat": [data["coord"]["lat"]],
        "lon": [data["coord"]["lon"]]
    })
    st.map(map_data, zoom=10, size=10, use_container_width=True)

def display_forecast(data):
    if data.get("cod") != "200":
        st.error("Error al cargar el pronóstico.")
        return

    forecast_data = data["list"]

    df = pd.DataFrame({
        "Fecha": [pd.to_datetime(entry["dt_txt"]) for entry in forecast_data],
        "Temperatura (°C)": [entry["main"]["temp"] for entry in forecast_data],
        "Humedad (%)": [entry["main"]["humidity"] for entry in forecast_data],
        "Viento (m/s)": [entry["wind"]["speed"] for entry in forecast_data],
        "Condición": [entry["weather"][0]["description"].capitalize() for entry in forecast_data],
        "Icono": [WEATHER_ICONS.get(entry["weather"][0]["main"].lower(), "🌤️") for entry in forecast_data],
        "Lluvia (mm)": [entry.get("rain", {}).get("3h", 0) for entry in forecast_data]
    })

    st.subheader("📅 Próximos 3 días")
    df_daily = df.copy()
    df_daily["Día"] = df_daily["Fecha"].dt.date
    daily_stats = df_daily.groupby("Día").agg({
        "Temperatura (°C)": ["min", "max"],
        "Lluvia (mm)": "sum",
        "Condición": lambda x: x.mode()[0],
        "Icono": "first"
    }).reset_index()
    daily_stats.columns = ["Día", "Mínima", "Máxima", "Lluvia acumulada", "Condición predominante", "Icono"]

    cols = st.columns(3)
    for i in range(3):
        if i < len(daily_stats):
            day = daily_stats.iloc[i]
            cols[i].markdown(f"""
            <div style="background: rgba(255,255,255,0.1); border-radius: 10px; padding: 15px; text-align: center">
                <h4>{day['Día'].strftime('%A %d')}</h4>
                <p style="font-size: 30px">{day['Icono']}</p>
                <p><b>{day['Condición predominante']}</b></p>
                <p>Max: {round(day['Máxima'])}°C</p>
                <p>Min: {round(day['Mínima'])}°C</p>
            </div>
            """, unsafe_allow_html=True)

    st.subheader("📊 Pronóstico por horas")
    fig_temp = px.line(df, x="Fecha", y="Temperatura (°C)", title="Variación de temperatura")
    st.plotly_chart(fig_temp, use_container_width=True)

    fig_combined = px.bar(df, x="Fecha", y=["Humedad (%)", "Lluvia (mm)"],
                         title="Humedad y Precipitación", barmode='group')
    st.plotly_chart(fig_combined, use_container_width=True)

    st.subheader("📋 Detalle por horas")
    st.dataframe(
        df.head(12),
        column_config={
            "Fecha": "📅 Hora",
            "Temperatura (°C)": "🌡️ Temp",
            "Humedad (%)": "💧 Humedad",
            "Viento (m/s)": "🌬️ Viento",
            "Condición": "☁️ Estado",
            "Lluvia (mm)": "🌧️ Lluvia"
        },
        hide_index=True,
        use_container_width=True
    )

def display_agricultural_insights(current_weather, ciudad):
    temp = current_weather["main"]["temp"]
    humedad = current_weather["main"]["humidity"]
    lluvia_prob = current_weather.get("rain", {}).get("3h", 0)

    st.subheader("🌿 Recomendaciones agrícolas")
    recs = recomendaciones_agricolas(temp, humedad, lluvia_prob, ciudad)
    for r in recs:
        st.markdown(f"- {r}")

    st.subheader("📅 Calendario agrícola del mes")
    region, evento = calendario_region(ciudad)
    st.markdown(f"**Región:** {region}")
    st.markdown(f"**{datetime.now().strftime('%B').capitalize()}:** {evento}")
