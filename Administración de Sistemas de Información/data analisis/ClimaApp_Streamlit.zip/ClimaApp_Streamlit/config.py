
CIUDADES_NICARAGUA = [
    "Managua", "León", "Granada", "Masaya", "Estelí", "Matagalpa", "Chinandega",
    "Jinotega", "Bluefields", "Juigalpa", "Ocotal", "Boaco", "Rivas", "Somoto",
    "San Carlos", "Puerto Cabezas", "Nueva Guinea"
]


# API Keys y endpoints
API_KEY = "de00599c029a6499d0dd0a832cdcdb36"
DEFAULT_CITY = "Ciudad de México"
UNITS = "metric"
LANG = "es"

# URLs APIs
CURRENT_WEATHER_URL = "https://api.openweathermap.org/data/2.5/weather"
FORECAST_URL = "https://api.openweathermap.org/data/2.5/forecast"
AIR_QUALITY_URL = "http://api.openweathermap.org/data/2.5/air_pollution"
UV_API_URL = "https://api.openweathermap.org/data/2.5/uvi"